package com.infy.proxy.dto;

import java.util.Arrays;
import java.util.List;

public class MetaDataDTO {

	private List<String> allow;
	private String href;
	private List<LinkPojo> links;

	public List<String> getAllow() {
		return allow;
	}

	public void setAllow(List<String> allow) {
		this.allow = allow;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public List<LinkPojo> getLinks() {
		return links;
	}

	public void setLinks(List<LinkPojo> links) {
		this.links = links;
	}

}
