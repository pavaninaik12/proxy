package com.infy.proxy.dto;

public class BearerTokenDTO {

	private String bearerToken;
	private long expiresInMilliseconds;

	public String getBearerToken() {
		return bearerToken;
	}

	public void setBearerToken(String bearerToken) {
		this.bearerToken = bearerToken;
	}

	public long getExpiresInMilliseconds() {
		return expiresInMilliseconds;
	}

	public void setExpiresInMilliseconds(long expiresInMilliseconds) {
		this.expiresInMilliseconds = expiresInMilliseconds;
	}

	@Override
	public String toString() {
		return "BearerTokenDTO [bearerToken=" + bearerToken + ", expiresInMilliseconds=" + expiresInMilliseconds + "]";
	}

}
