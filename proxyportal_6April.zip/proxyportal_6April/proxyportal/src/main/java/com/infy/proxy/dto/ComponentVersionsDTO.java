package com.infy.proxy.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComponentVersionsDTO {

	private int totalCount;
	private List<ComponentVersionDTO> items;
	private List<AppliedFilterDTO> appliedFilters;
	private MetaDataDTO _meta;

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public List<ComponentVersionDTO> getItems() {
		return items;
	}

	public void setItems(List<ComponentVersionDTO> items) {
		this.items = items;
	}

	public List<AppliedFilterDTO> getAppliedFilters() {
		return appliedFilters;
	}

	public void setAppliedFilters(List<AppliedFilterDTO> appliedFilters) {
		this.appliedFilters = appliedFilters;
	}

	public MetaDataDTO get_meta() {
		return _meta;
	}

	public void set_meta(MetaDataDTO _meta) {
		this._meta = _meta;
	}

	@Override
	public String toString() {
		return "ComponentVersionsDTO [totalCount=" + totalCount + ", items=" + items + ", appliedFilters="
				+ appliedFilters + ", _meta=" + _meta + "]";
	}

}
