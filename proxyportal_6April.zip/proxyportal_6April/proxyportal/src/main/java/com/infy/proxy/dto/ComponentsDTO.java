package com.infy.proxy.dto;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public class ComponentsDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long totalCount;
	private List<ItemDTO> items;
	private String[] appliedFilters;

	private MetaDataDTO _meta;

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public List<ItemDTO> getItems() {
		return items;
	}

	public void setItems(List<ItemDTO> items) {
		this.items = items;
	}

	public String[] getAppliedFilters() {
		return appliedFilters;
	}

	public void setAppliedFilters(String[] appliedFilters) {
		this.appliedFilters = appliedFilters;
	}

	public MetaDataDTO get_meta() {
		return _meta;
	}

	public void set_meta(MetaDataDTO _meta) {
		this._meta = _meta;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ComponentsDTO [totalCount=" + totalCount + ", items=" + items + ", appliedFilters="
				+ Arrays.toString(appliedFilters) + ", _meta=" + _meta + "]";
	}

}
