package com.infy.proxy.dto;

public class HitsPojo {
	private String component;
	private FieldPojo fields;

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public FieldPojo getFields() {
		return fields;
	}

	public void setFields(FieldPojo fields) {
		this.fields = fields;
	}

	@Override
	public String toString() {
		return "HitsPojo [component=" + component + ", fields=" + fields + "]";
	}

}
