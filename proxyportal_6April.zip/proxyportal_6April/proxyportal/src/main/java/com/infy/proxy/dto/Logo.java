package com.infy.proxy.dto;

public class Logo {

	private String smallLogoUrl;
	private String mediumLogoUrl;

	public String getSmallLogoUrl() {
		return smallLogoUrl;
	}

	public void setSmallLogoUrl(String smallLogoUrl) {
		this.smallLogoUrl = smallLogoUrl;
	}

	public String getMediumLogoUrl() {
		return mediumLogoUrl;
	}

	public void setMediumLogoUrl(String mediumLogoUrl) {
		this.mediumLogoUrl = mediumLogoUrl;
	}

	@Override
	public String toString() {
		return "Logo [smallLogoUrl=" + smallLogoUrl + ", mediumLogoUrl=" + mediumLogoUrl + "]";
	}

}
