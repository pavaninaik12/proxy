package com.infy.proxy.services;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infy.proxy.dto.BearerTokenDTO;
import com.infy.proxy.dto.ComponentVersionDTO;
import com.infy.proxy.dto.ComponentVersionsDTO;
import com.infy.proxy.dto.ComponentsDTO;
import com.infy.proxy.dto.LinkPojo;
import com.infy.proxy.dto.VulnerabilitysDTO;

@Service
public class ResourceService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${blackduck.components.url}")
	private String COMPONENTS_URL;

	@Value("${blackduck.access.token}")
	private String ACCESS_TOKEN;

	@Value("${blackduck.authenticate.url}")
	private String AUTHENTICATE_URL;

	@Value("${blackduck.search.url}")
	private String SEARCH_URL;

	public VulnerabilitysDTO fetchVulnerabilityDataFromServer(String componentName, String versionId) {

		HttpEntity<String> jwtEntity = getHttpEntityWithHeadersInfo();

		final String uri = SEARCH_URL + componentName;

		String VULNERABILITYURI = "";

		ResponseEntity<ComponentsDTO> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, jwtEntity,
				ComponentsDTO.class);

		String componentId = responseEntity.getBody().getItems().get(0).getHits().get(0).getComponent();

		String[] split = componentId.split("/");

		componentId = split[split.length - 1];

		ResponseEntity<ComponentVersionsDTO> response = restTemplate.exchange(
				COMPONENTS_URL + "/" + componentId + "/versions?limit=1000", HttpMethod.GET, jwtEntity,
				ComponentVersionsDTO.class);

		for (ComponentVersionDTO dto : response.getBody().getItems()) {
			// System.out.println(dto.getVersionName()+"=="+versionId);
			if (dto.getVersionName().equals(new String(versionId))) {
				List<LinkPojo> collect = dto.get_meta().getLinks().stream()
						.filter(s -> s.getRel().equals(new String("vulnerabilities"))).collect(Collectors.toList());

				VULNERABILITYURI = collect.get(0).getHref();

				break;
			}
		}

		ResponseEntity<VulnerabilitysDTO> exchange = restTemplate.exchange(VULNERABILITYURI+"?limit=1000", HttpMethod.GET, jwtEntity,
				VulnerabilitysDTO.class);

		return exchange.getBody();

	}

	private HttpEntity<String> getHttpEntityWithHeadersInfo() {
		HttpHeaders headers = new HttpHeaders();

		headers.setBearerAuth(getBearerToken());
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<String> jwtEntity = new HttpEntity<String>(headers);

		return jwtEntity;

	}

	public String getBearerToken() {
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Accept", "application/vnd.blackducksoftware.user-4+json");
			headers.set("Authorization", "token " + ACCESS_TOKEN);
			HttpEntity<Object> entity = new HttpEntity<>(headers);
			BearerTokenDTO response = restTemplate.postForObject(AUTHENTICATE_URL, entity, BearerTokenDTO.class);
			// System.out.println(response);
			return response.getBearerToken();
		} catch (RuntimeException e) {
			// logger.error("Exception in log in API :: " + e.getMessage(), e);
		}
		return null;
	}
}
