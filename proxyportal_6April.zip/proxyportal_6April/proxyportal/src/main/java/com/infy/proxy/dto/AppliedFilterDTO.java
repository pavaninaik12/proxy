package com.infy.proxy.dto;

import java.util.Arrays;
import java.util.List;

public class AppliedFilterDTO {

	private String name;
	private String label;
	private List<SelectedDTO> selected;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<SelectedDTO> getSelected() {
		return selected;
	}

	public void setSelected(List<SelectedDTO> selected) {
		this.selected = selected;
	}



}

class SelectedDTO {
	private String key;
	private String label;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Override
	public String toString() {
		return "SelectedDTO [key=" + key + ", label=" + label + "]";
	}

}