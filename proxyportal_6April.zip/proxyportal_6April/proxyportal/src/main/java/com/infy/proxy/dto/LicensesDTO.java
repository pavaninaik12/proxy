package com.infy.proxy.dto;

import java.util.Arrays;
import java.util.List;

public class LicensesDTO {

	private String license;
	private List<LicensesDTO> licenses;
	private String name;
	private String ownership;
	private String licenseDisplay;
	private String codeSharing;

	public String getLicense() {
		return license;
	}

	public void setLicense(String license) {
		this.license = license;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwnership() {
		return ownership;
	}

	public void setOwnership(String ownership) {
		this.ownership = ownership;
	}

	public String getLicenseDisplay() {
		return licenseDisplay;
	}

	public void setLicenseDisplay(String licenseDisplay) {
		this.licenseDisplay = licenseDisplay;
	}

	public String getCodeSharing() {
		return codeSharing;
	}

	public void setCodeSharing(String codeSharing) {
		this.codeSharing = codeSharing;
	}

	public List<LicensesDTO> getLicenses() {
		return licenses;
	}

	public void setLicenses(List<LicensesDTO> licenses) {
		this.licenses = licenses;
	}

}
