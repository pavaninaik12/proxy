package com.infy.proxy.dto;

import java.util.List;

public class ComponentDTO {
	private String name;
	private String description;
	private String url;
	private String approvalStatus;
	private String primaryLanguage;
	private Logo logo;
	private List<String> additionalHomepages;
	private String source;
	private String type;
	private boolean migrated;
	private MetaDataDTO _meta;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getPrimaryLanguage() {
		return primaryLanguage;
	}

	public void setPrimaryLanguage(String primaryLanguage) {
		this.primaryLanguage = primaryLanguage;
	}

	public Logo getLogo() {
		return logo;
	}

	public void setLogo(Logo logo) {
		this.logo = logo;
	}

	public List<String> getAdditionalHomepages() {
		return additionalHomepages;
	}

	public void setAdditionalHomepages(List<String> additionalHomepages) {
		this.additionalHomepages = additionalHomepages;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isMigrated() {
		return migrated;
	}

	public void setMigrated(boolean migrated) {
		this.migrated = migrated;
	}

	@Override
	public String toString() {
		return "ComponentDTO [name=" + name + ", description=" + description + ", url=" + url + ", approvalStatus="
				+ approvalStatus + ", primaryLanguage=" + primaryLanguage + ", logo=" + logo + ", additionalHomepages="
				+ additionalHomepages + ", source=" + source + ", type=" + type + ", migrated=" + migrated + ", _meta="
				+ _meta + "]";
	}

	public MetaDataDTO get_meta() {
		return _meta;
	}

	public void set_meta(MetaDataDTO _meta) {
		this._meta = _meta;
	}

}
