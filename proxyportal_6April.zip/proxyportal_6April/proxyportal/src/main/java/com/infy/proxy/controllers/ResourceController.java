package com.infy.proxy.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.infy.proxy.dto.VulnerabilitysDTO;
import com.infy.proxy.services.ResourceService;


@Controller
public class ResourceController {
	
	@Autowired
	ResourceService service;
	

	@GetMapping("/")
	public String getHome()
	{
		return "index.jsp";
	}
	
	@PostMapping("/fetchData")
	public String getData(@RequestParam("cmpname") String componentName,@RequestParam("cmpversion") String componentVersionNumber,Model model)
	{
		VulnerabilitysDTO vulnerabilitys = service.fetchVulnerabilityDataFromServer(componentName, componentVersionNumber);

		model.addAttribute("vulnerabilitysList", vulnerabilitys);
		model.addAttribute("cmpname", componentName);
		model.addAttribute("cmpversion", componentVersionNumber);
		return "displayDetails.jsp";
	}
}
