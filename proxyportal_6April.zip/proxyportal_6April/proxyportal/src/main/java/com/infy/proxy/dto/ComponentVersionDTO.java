package com.infy.proxy.dto;

import java.sql.Timestamp;
import java.util.Arrays;

public class ComponentVersionDTO implements Comparable<ComponentVersionDTO>{

	private String versionName;
	private Timestamp releasedOn;
	private String approvalStatus;
	private LicenseDTO license;
	private String source;
	private String type;
	private String[] additionalHomePages;
	private boolean migrated;
	private MetaDataDTO _meta;
	
	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public Timestamp getReleasedOn() {
		return releasedOn;
	}

	public void setReleasedOn(Timestamp releasedOn) {
		this.releasedOn = releasedOn;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public LicenseDTO getLicense() {
		return license;
	}

	public void setLicense(LicenseDTO license) {
		this.license = license;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String[] getAdditionalHomePages() {
		return additionalHomePages;
	}

	public void setAdditionalHomePages(String[] additionalHomePages) {
		this.additionalHomePages = additionalHomePages;
	}

	public boolean isMigrated() {
		return migrated;
	}

	public void setMigrated(boolean migrated) {
		this.migrated = migrated;
	}

	public MetaDataDTO get_meta() {
		return _meta;
	}

	public void set_meta(MetaDataDTO _meta) {
		this._meta = _meta;
	}


	@Override
	public String toString() {
		return "ComponentVersionDTO [versionName=" + versionName + ", releasedOn=" + releasedOn + ", approvalStatus="
				+ approvalStatus + ", license=" + license + ", source=" + source + ", type=" + type
				+ ", additionalHomePages=" + Arrays.toString(additionalHomePages) + ", migrated=" + migrated
				+ ", _meta=" + _meta + "]";
	}

	@Override
	  public int compareTo(ComponentVersionDTO cv) {
	    if (getReleasedOn() == null || cv.getReleasedOn() == null) {
	      return 0;
	    }
	    return getReleasedOn().compareTo(cv.getReleasedOn());
	  }
}
