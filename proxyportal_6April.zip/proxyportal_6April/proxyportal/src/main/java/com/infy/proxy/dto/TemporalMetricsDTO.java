package com.infy.proxy.dto;

public class TemporalMetricsDTO {
	private String remediationLevel;
	private String reportConfidence;
	private double score;
	private String exploitability;

	public String getRemediationLevel() {
		return remediationLevel;
	}

	public void setRemediationLevel(String remediationLevel) {
		this.remediationLevel = remediationLevel;
	}

	public String getReportConfidence() {
		return reportConfidence;
	}

	public void setReportConfidence(String reportConfidence) {
		this.reportConfidence = reportConfidence;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public String getExploitability() {
		return exploitability;
	}

	public void setExploitability(String exploitability) {
		this.exploitability = exploitability;
	}

	@Override
	public String toString() {
		return "TemporalMetrics [remediationLevel=" + remediationLevel + ", reportConfidence=" + reportConfidence
				+ ", score=" + score + ", exploitability=" + exploitability + "]";
	}

}
