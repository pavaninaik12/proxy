package com.infy.proxy.dto;

import java.util.Arrays;
import java.util.List;

public class LicenseDTO {

	private String type;
	private List<LicensesDTO> licenses;
	private String licenseDisplay;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLicenseDisplay() {
		return licenseDisplay;
	}

	public void setLicenseDisplay(String licenseDisplay) {
		this.licenseDisplay = licenseDisplay;
	}

	public List<LicensesDTO> getLicenses() {
		return licenses;
	}

	public void setLicenses(List<LicensesDTO> licenses) {
		this.licenses = licenses;
	}


}
