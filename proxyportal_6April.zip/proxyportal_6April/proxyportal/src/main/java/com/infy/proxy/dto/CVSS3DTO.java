package com.infy.proxy.dto;

public class CVSS3DTO {

	private double baseScore;
	private double impactSubscore;
	private double exploitabilitySubscore;
	private String severity;
	private String attackVector;
	private String attackComplexity;
	private String authentication;
	private String confidentialityImpact;
	private String integrityImpact;
	private String availabilityImpact;
	private String privilegesRequired;
	private String scope;
	private String userInteraction;
	private TemporalMetricsDTO temporalMetrics;
	private String vector;

	public double getBaseScore() {
		return baseScore;
	}

	public void setBaseScore(double baseScore) {
		this.baseScore = baseScore;
	}

	public double getImpactSubscore() {
		return impactSubscore;
	}

	public void setImpactSubscore(double impactSubscore) {
		this.impactSubscore = impactSubscore;
	}

	public double getExploitabilitySubscore() {
		return exploitabilitySubscore;
	}

	public void setExploitabilitySubscore(double exploitabilitySubscore) {
		this.exploitabilitySubscore = exploitabilitySubscore;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getAuthentication() {
		return authentication;
	}

	public void setAuthentication(String authentication) {
		this.authentication = authentication;
	}

	public String getConfidentialityImpact() {
		return confidentialityImpact;
	}

	public void setConfidentialityImpact(String confidentialityImpact) {
		this.confidentialityImpact = confidentialityImpact;
	}

	public String getIntegrityImpact() {
		return integrityImpact;
	}

	public void setIntegrityImpact(String integrityImpact) {
		this.integrityImpact = integrityImpact;
	}

	public String getAvailabilityImpact() {
		return availabilityImpact;
	}

	public void setAvailabilityImpact(String availabilityImpact) {
		this.availabilityImpact = availabilityImpact;
	}

	public String getPrivilegesRequired() {
		return privilegesRequired;
	}

	public void setPrivilegesRequired(String privilegesRequired) {
		this.privilegesRequired = privilegesRequired;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getUserInteraction() {
		return userInteraction;
	}

	public void setUserInteraction(String userInteraction) {
		this.userInteraction = userInteraction;
	}

	public String getVector() {
		return vector;
	}

	public void setVector(String vector) {
		this.vector = vector;
	}

	public TemporalMetricsDTO getTemporalMetrics() {
		return temporalMetrics;
	}

	public void setTemporalMetrics(TemporalMetricsDTO temporalMetrics) {
		this.temporalMetrics = temporalMetrics;
	}

	public String getAttackVector() {
		return attackVector;
	}

	public void setAttackVector(String attackVector) {
		this.attackVector = attackVector;
	}

	public String getAttackComplexity() {
		return attackComplexity;
	}

	public void setAttackComplexity(String attackComplexity) {
		this.attackComplexity = attackComplexity;
	}

	@Override
	public String toString() {
		return "CVSS3DTO [baseScore=" + baseScore + ", impactSubscore=" + impactSubscore + ", exploitabilitySubscore="
				+ exploitabilitySubscore + ", severity=" + severity + ", attackVector=" + attackVector
				+ ", attackComplexity=" + attackComplexity + ", authentication=" + authentication
				+ ", confidentialityImpact=" + confidentialityImpact + ", integrityImpact=" + integrityImpact
				+ ", availabilityImpact=" + availabilityImpact + ", privilegesRequired=" + privilegesRequired
				+ ", scope=" + scope + ", userInteraction=" + userInteraction + ", temporalMetrics=" + temporalMetrics
				+ ", vector=" + vector + "]";
	}

}
