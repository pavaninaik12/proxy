package com.infy.proxy.dto;

import java.util.Arrays;

public class FieldPojo {

	private String[] score;
	private String[] num_watchers;
	private String[] ownership;
	private String[] release_count;
	private String[] name;
	private String[] description;
	private String[] doc_type;
	private String[] tags;
	private String[] primary_language;
	private String[] component;
	private String[] url;
	private String[] medium_logo_url;
	public String[] getScore() {
		return score;
	}
	public void setScore(String[] score) {
		this.score = score;
	}
	public String[] getNum_watchers() {
		return num_watchers;
	}
	public void setNum_watchers(String[] num_watchers) {
		this.num_watchers = num_watchers;
	}
	public String[] getOwnership() {
		return ownership;
	}
	public void setOwnership(String[] ownership) {
		this.ownership = ownership;
	}
	public String[] getRelease_count() {
		return release_count;
	}
	public void setRelease_count(String[] release_count) {
		this.release_count = release_count;
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
	public String[] getDescription() {
		return description;
	}
	public void setDescription(String[] description) {
		this.description = description;
	}
	public String[] getDoc_type() {
		return doc_type;
	}
	public void setDoc_type(String[] doc_type) {
		this.doc_type = doc_type;
	}
	public String[] getTags() {
		return tags;
	}
	public void setTags(String[] tags) {
		this.tags = tags;
	}
	public String[] getPrimary_language() {
		return primary_language;
	}
	public void setPrimary_language(String[] primary_language) {
		this.primary_language = primary_language;
	}
	public String[] getComponent() {
		return component;
	}
	public void setComponent(String[] component) {
		this.component = component;
	}
	public String[] getUrl() {
		return url;
	}
	public void setUrl(String[] url) {
		this.url = url;
	}
	public String[] getMedium_logo_url() {
		return medium_logo_url;
	}
	public void setMedium_logo_url(String[] medium_logo_url) {
		this.medium_logo_url = medium_logo_url;
	}
	@Override
	public String toString() {
		return "FieldPojo [score=" + Arrays.toString(score) + ", num_watchers=" + Arrays.toString(num_watchers)
				+ ", ownership=" + Arrays.toString(ownership) + ", release_count=" + Arrays.toString(release_count)
				+ ", name=" + Arrays.toString(name) + ", description=" + Arrays.toString(description) + ", doc_type="
				+ Arrays.toString(doc_type) + ", tags=" + Arrays.toString(tags) + ", primary_language="
				+ Arrays.toString(primary_language) + ", component=" + Arrays.toString(component) + ", url="
				+ Arrays.toString(url) + ", medium_logo_url=" + Arrays.toString(medium_logo_url) + "]";
	}

}
