package com.infy.proxy.dto;

import java.util.Arrays;
import java.util.List;

public class ItemDTO {

	private SearchResultSpecPojo searchResultSpec;
	private SearchResultStatisticsPojo searchResultStatistics;

	private FacetPojo[] facets;

	private List<HitsPojo> hits;

	private String localError;
	private String remoteError;

	public SearchResultSpecPojo getSearchResultSpec() {
		return searchResultSpec;
	}

	public void setSearchResultSpec(SearchResultSpecPojo searchResultSpec) {
		this.searchResultSpec = searchResultSpec;
	}

	public SearchResultStatisticsPojo getSearchResultStatistics() {
		return searchResultStatistics;
	}

	public void setSearchResultStatistics(SearchResultStatisticsPojo searchResultStatistics) {
		this.searchResultStatistics = searchResultStatistics;
	}

	public List<HitsPojo> getHits() {
		return hits;
	}

	public void setHits(List<HitsPojo> hits) {
		this.hits = hits;
	}

	public String getLocalError() {
		return localError;
	}

	public void setLocalError(String localError) {
		this.localError = localError;
	}

	public String getRemoteError() {
		return remoteError;
	}

	public void setRemoteError(String remoteError) {
		this.remoteError = remoteError;
	}

	@Override
	public String toString() {
		return "ItemDTO [searchResultSpec=" + searchResultSpec + ", searchResultStatistics=" + searchResultStatistics
				+ ", facets=" + Arrays.toString(facets) + ", hits=" + hits.toString() + ", localError="
				+ localError + ", remoteError=" + remoteError + "]";
	}

}



class FacetPojo {
	private FacetTypePojo facetType;
	private FacetValuePojo facetValues;

	public FacetTypePojo getFacetType() {
		return facetType;
	}

	public void setFacetType(FacetTypePojo facetType) {
		this.facetType = facetType;
	}

	public FacetValuePojo getFacetValues() {
		return facetValues;
	}

	public void setFacetValues(FacetValuePojo facetValues) {
		this.facetValues = facetValues;
	}

	@Override
	public String toString() {
		return "FacetPojo [facetType=" + facetType + ", facetValues=" + facetValues + "]";
	}

}

class FacetTypePojo {
	private String fieldName;
	private boolean singleSelect;
	private boolean translateValues;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public boolean isSingleSelect() {
		return singleSelect;
	}

	public void setSingleSelect(boolean singleSelect) {
		this.singleSelect = singleSelect;
	}

	public boolean isTranslateValues() {
		return translateValues;
	}

	public void setTranslateValues(boolean translateValues) {
		this.translateValues = translateValues;
	}

	@Override
	public String toString() {
		return "FacetTypePojo [fieldName=" + fieldName + ", singleSelect=" + singleSelect + ", translateValues="
				+ translateValues + "]";
	}

}

class FacetValuePojo {
	private int value;
	private int filterValue;
	private int count;
	private boolean selected;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getFilterValue() {
		return filterValue;
	}

	public void setFilterValue(int filterValue) {
		this.filterValue = filterValue;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public String toString() {
		return "FacetValuePojo [value=" + value + ", filterValue=" + filterValue + ", count=" + count + ", selected="
				+ selected + "]";
	}

}

class SearchResultStatisticsPojo {
	private int numResultsInThisPage;
	private int numResultsFound;
	private int timeTakenMs;

	public int getNumResultsInThisPage() {
		return numResultsInThisPage;
	}

	public void setNumResultsInThisPage(int numResultsInThisPage) {
		this.numResultsInThisPage = numResultsInThisPage;
	}

	public int getNumResultsFound() {
		return numResultsFound;
	}

	public void setNumResultsFound(int numResultsFound) {
		this.numResultsFound = numResultsFound;
	}

	public int getTimeTakenMs() {
		return timeTakenMs;
	}

	public void setTimeTakenMs(int timeTakenMs) {
		this.timeTakenMs = timeTakenMs;
	}

	@Override
	public String toString() {
		return "SearchResultStatisticsPojo [numResultsInThisPage=" + numResultsInThisPage + ", numResultsFound="
				+ numResultsFound + ", timeTakenMs=" + timeTakenMs + "]";
	}

}

class SearchResultSpecPojo {
	private int rowStart;
	private int numResultsInPage;

	public int getRowStart() {
		return rowStart;
	}

	public void setRowStart(int rowStart) {
		this.rowStart = rowStart;
	}

	public int getNumResultsInPage() {
		return numResultsInPage;
	}

	public void setNumResultsInPage(int numResultsInPage) {
		this.numResultsInPage = numResultsInPage;
	}

	@Override
	public String toString() {
		return "SearchResultSpecPojo [rowStart=" + rowStart + ", numResultsInPage=" + numResultsInPage + "]";
	}

}